const admin = require('firebase-admin');
const serviceAccount = require('../../serviceAccountKey.json');

// Ensure storage bucket is configured for uploads
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    storageBucket: process.env.GCLOUD_STORAGE_BUCKET || `${serviceAccount.project_id}.appspot.com`
});

const db = admin.firestore();

// Safe diagnostic log to confirm Firestore target project (no secrets exposed)
try {
	const projectId = serviceAccount.project_id || (admin.app().options && admin.app().options.projectId) || 'unknown-project';
	console.log(`[Firestore] Connected to project: ${projectId}`);
} catch (_) {
	// ignore
}

module.exports = db;