const db = require('../config/firebase');
const admin = require('firebase-admin');

exports.createPost = async (req, res) => {
    const { user, avatar, text, mood, media, mediaType } = req.body;
    try {
        let finalMediaUrl = media || null;
        let finalMediaType = mediaType || null;

        // If media is a data URL, upload to Firebase Storage and use a signed URL
        if (typeof media === 'string' && media.startsWith('data:')) {
            const matches = media.match(/^data:(.*?);base64,(.*)$/);
            if (!matches) {
                return res.status(400).json({ message: 'Invalid media data URL' });
            }
            const mimeType = matches[1] || 'application/octet-stream';
            const base64 = matches[2];
            const buffer = Buffer.from(base64, 'base64');
            const extension = mimeType.split('/')[1] || 'bin';
            const objectName = `posts/${Date.now()}_${Math.random().toString(36).slice(2)}.${extension}`;

            const bucket = admin.storage().bucket();
            const file = bucket.file(objectName);
            await file.save(buffer, {
                metadata: { contentType: mimeType, cacheControl: 'public, max-age=31536000' },
                resumable: false
            });
            const [signedUrl] = await file.getSignedUrl({ action: 'read', expires: '2100-01-01' });
            finalMediaUrl = signedUrl;
            finalMediaType = mimeType;
        }

        const newPostRef = db.collection('posts').doc();
        await newPostRef.set({
            user,
            avatar,
            text,
            mood,
            media: finalMediaUrl,
            mediaType: finalMediaType,
            time: new Date().toISOString()
        });
        res.status(201).json({ message: 'Post created', postId: newPostRef.id, media: finalMediaUrl, mediaType: finalMediaType });
    } catch (error) {
        res.status(500).json({ message: 'Error creating post', error });
    }
};

exports.getPosts = async (req, res) => {
    try {
        const postsSnapshot = await db.collection('posts').orderBy('time', 'desc').get();
        const posts = postsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        res.status(200).json(posts);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching posts', error });
    }
};