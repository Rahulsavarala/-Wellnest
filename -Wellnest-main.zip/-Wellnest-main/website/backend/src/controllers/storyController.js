const db = require('../config/firebase');
const admin = require('firebase-admin');

exports.createStory = async (req, res) => {
    const { user, url, type } = req.body;
    try {
        let finalUrl = url;
        // If the payload is a data URL base64, upload to Firebase Storage and use public URL
        if (typeof url === 'string' && url.startsWith('data:')) {
            const matches = url.match(/^data:(.*?);base64,(.*)$/);
            if (!matches) {
                return res.status(400).json({ message: 'Invalid data URL' });
            }
            const mimeType = matches[1] || 'application/octet-stream';
            const base64 = matches[2];
            const buffer = Buffer.from(base64, 'base64');
            const extension = mimeType.split('/')[1] || 'bin';
            const objectName = `stories/${Date.now()}_${Math.random().toString(36).slice(2)}.${extension}`;

            const bucket = admin.storage().bucket();
            const file = bucket.file(objectName);
            await file.save(buffer, {
                metadata: { contentType: mimeType, cacheControl: 'public, max-age=31536000' },
                resumable: false
            });
            // Generate a long-lived signed URL for read access
            const [signedUrl] = await file.getSignedUrl({
                action: 'read',
                expires: '2100-01-01'
            });
            finalUrl = signedUrl;
        }

        const newStoryRef = db.collection('stories').doc();
        await newStoryRef.set({ user, url: finalUrl, type, time: new Date().toISOString() });
        res.status(201).json({ message: 'Story created', storyId: newStoryRef.id, url: finalUrl });
    } catch (error) {
        // Log detailed error server-side for troubleshooting
        console.error('[createStory] Failed to create story:', {
            message: error && error.message,
            code: error && error.code
        });
        res.status(500).json({ message: 'Error creating story', error: (error && error.message) || 'unknown' });
    }
};

exports.getStories = async (req, res) => {
    try {
        const storiesSnapshot = await db.collection('stories').orderBy('time', 'desc').get();
        const stories = storiesSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        res.status(200).json(stories);
    } catch (error) {
        console.error('[getStories] Failed to fetch stories:', {
            message: error && error.message,
            code: error && error.code
        });
        res.status(500).json({ message: 'Error fetching stories', error: (error && error.message) || 'unknown' });
    }
};

exports.deleteStory = async (req, res) => {
    const { id } = req.params;
    try {
        const docRef = db.collection('stories').doc(id);
        const docSnap = await docRef.get();
        if (!docSnap.exists) {
            return res.status(404).json({ message: 'Story not found' });
        }
        // Attempt to delete associated storage object if present
        try {
            const data = docSnap.data();
            const url = data && data.url;
            if (typeof url === 'string') {
                const admin = require('firebase-admin');
                const bucket = admin.storage().bucket();
                let objectPath = null;
                if (url.includes('storage.googleapis.com/')) {
                    // e.g. https://storage.googleapis.com/<bucket>/<object>[?query]
                    const afterDomain = url.split('storage.googleapis.com/')[1] || '';
                    const parts = afterDomain.split('/');
                    parts.shift(); // remove bucket name
                    objectPath = parts.join('/').split('?')[0];
                }
                if (objectPath) {
                    await bucket.file(objectPath).delete({ ignoreNotFound: true });
                }
            }
        } catch (e) {
            console.warn('[deleteStory] Storage deletion skipped:', e && e.message);
        }

        await docRef.delete();
        res.status(200).json({ message: 'Story deleted' });
    } catch (error) {
        console.error('[deleteStory] Failed to delete story:', {
            message: error && error.message,
            code: error && error.code
        });
        res.status(500).json({ message: 'Error deleting story', error: (error && error.message) || 'unknown' });
    }
};