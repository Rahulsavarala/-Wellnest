const admin = require('firebase-admin');

const auth = async (req, res, next) => {
    try {
        const token = req.header('Authorization')?.replace('Bearer ', '');
        console.log('Auth middleware - Token received:', token ? token.substring(0, 50) + '...' : 'No token');
        
        if (!token) {
            console.log('Auth middleware - No token provided');
            return res.status(401).json({ message: 'No token, authorization denied' });
        }

        console.log('Auth middleware - Verifying token...');
        const decodedToken = await admin.auth().verifyIdToken(token);
        console.log('Auth middleware - Token verified successfully:', decodedToken.uid);
        req.user = decodedToken;
        next();
    } catch (error) {
        console.error('Auth middleware - Token verification failed:', error.message);
        res.status(401).json({ message: 'Token is not valid: ' + error.message });
    }
};

module.exports = auth;
