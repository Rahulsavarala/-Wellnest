const express = require('express');
const router = express.Router();
const postController = require('../controllers/postController');
// const auth = require('../middleware/auth');

// Disable auth for local development so media posts work without tokens
router.post('/', /* auth, */ postController.createPost);
router.get('/', postController.getPosts);
module.exports = router;