const express = require('express');
const router = express.Router();
const storyController = require('../controllers/storyController');
// NOTE: Auth temporarily disabled for local development to allow creating stories from static frontend.
// const auth = require('../middleware/auth');

router.post('/', /* auth, */ storyController.createStory);
router.get('/', storyController.getStories);
router.delete('/:id', /* auth, */ storyController.deleteStory);
module.exports = router;