# Firebase Setup Guide for WeShare

## Step 1: Get Firebase Web App Configuration

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Select your project: **dhack-a0417**
3. Click the gear icon (⚙️) next to "Project Overview"
4. Select "Project settings"
5. Scroll down to "Your apps" section
6. If you don't see a web app, click "Add app" and select the web icon (</>)
7. Give it a nickname like "WeShare Web App"
8. Copy the entire config object that looks like this:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
  authDomain: "dhack-a0417.firebaseapp.com",
  projectId: "dhack-a0417",
  storageBucket: "dhack-a0417.appspot.com",
  messagingSenderId: "110678439136882323413",
  appId: "1:110678439136882323413:web:XXXXXXXXXXXXXXXX"
};
```

## Step 2: Enable Email/Password Authentication

1. In Firebase Console, go to **Authentication** → **Sign-in method**
2. Click on **Email/Password**
3. Enable the first toggle (Email/Password)
4. Click **Save**

## Step 3: Update Your Code

Replace the config in `frontend/js/firebase-config.js` with the real config from Step 1.

## Step 4: Test

1. Start your backend: `cd backend && npm start`
2. Open `http://localhost:5000`
3. Try to sign up with a new email/password
4. Check Firebase Console → Authentication → Users to see the new user

## Troubleshooting

- If you get "Firebase: Error (auth/api-key-not-valid)", the API key is wrong
- If you get "Firebase: Error (auth/operation-not-allowed)", enable Email/Password auth
- If you get "Firebase: Error (auth/network-request-failed)", check your internet connection



