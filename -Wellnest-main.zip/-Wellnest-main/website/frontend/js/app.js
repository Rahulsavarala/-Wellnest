document.addEventListener('DOMContentLoaded', function() {
    // Get all "Get Started" buttons
    const getStartedBtns = document.querySelectorAll('.btn-signup');
    const loginBtns = document.querySelectorAll('.btn-login');

    // Add click event listeners for all signup buttons
    getStartedBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const authModal = document.getElementById('authModal');
            const signupTab = document.getElementById('signupTab');
            
            authModal.style.display = 'block';
            document.body.style.overflow = 'hidden';
            
            // Switch to signup tab
            const loginTab = document.getElementById('loginTab');
            const loginForm = document.getElementById('loginForm');
            const signupForm = document.getElementById('signupForm');

            loginTab.classList.remove('active');
            signupTab.classList.add('active');
            loginForm.style.display = 'none';
            signupForm.style.display = 'block';
        });
    });

    // Add click event listeners for all login buttons
    loginBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const authModal = document.getElementById('authModal');
            const loginTab = document.getElementById('loginTab');
            
            authModal.style.display = 'block';
            document.body.style.overflow = 'hidden';
            
            // Switch to login tab
            const signupTab = document.getElementById('signupTab');
            const loginForm = document.getElementById('loginForm');
            const signupForm = document.getElementById('signupForm');

            signupTab.classList.remove('active');
            loginTab.classList.add('active');
            signupForm.style.display = 'none';
            loginForm.style.display = 'block';
        });
    });

    // Feature card hover animations
    const featureCards = document.querySelectorAll('.feature-card');
    featureCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-5px)';
        });
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
        });
    });
});