// DOM Elements for Auth
const loginBtn = document.querySelector('.btn-login');
const signupBtn = document.querySelector('.btn-signup');
const authModal = document.getElementById('authModal');
const closeModal = document.querySelector('.close');
const loginTab = document.getElementById('loginTab');
const signupTab = document.getElementById('signupTab');
const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');
const loginSubmit = document.getElementById('loginSubmit');
const signupSubmit = document.getElementById('signupSubmit');

// User Data Storage
const users = JSON.parse(localStorage.getItem('users')) || [];
let currentUser = null;

// Helper Functions
function showModal() {
    authModal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function hideModal() {
    authModal.style.display = 'none';
    document.body.style.overflow = 'auto';
}

function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 3000);
}

function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validatePassword(password) {
    return password.length >= 6;
}

// Tab Switching
function switchTab(tab) {
    const isLogin = tab === 'login';
    loginTab.classList.toggle('active', isLogin);
    signupTab.classList.toggle('active', !isLogin);
    loginForm.style.display = isLogin ? 'block' : 'none';
    signupForm.style.display = isLogin ? 'none' : 'block';
}

// Authentication Functions
async function login(email, password) {
    try {
        const userCredential = await window.firebaseAuth.signInWithEmailAndPassword(email, password);
        currentUser = userCredential.user;
        updateUIForUser();
        hideModal();
        showToast('Login successful! Redirecting to dashboard...');
        setTimeout(() => {
            window.location.href = '../html/dashboard.html';
        }, 1000);
        return true;
    } catch (error) {
        showToast('Invalid email or password', 'error');
        return false;
    }
}

async function signup(name, email, password) {
    try {
        const userCredential = await window.firebaseAuth.createUserWithEmailAndPassword(email, password);
        await userCredential.user.updateProfile({ displayName: name });
        currentUser = userCredential.user;
        updateUIForUser();
        hideModal();
        showToast('Account created successfully! Redirecting to dashboard...');
        setTimeout(() => {
            window.location.href = '../html/dashboard.html';
        }, 1000);
        return true;
    } catch (error) {
        showToast('Email already exists or invalid', 'error');
        return false;
    }
}

function logout() {
    window.firebaseAuth.signOut().then(() => {
        currentUser = null;
        updateUIForUser();
        showToast('Logged out successfully');
    });
}

// UI Updates
function updateUIForUser() {
    const authButtons = document.querySelector('.nav-buttons');
    const userProfile = document.querySelector('.user-profile');
    if (window.firebaseAuth && window.firebaseAuth.currentUser) {
        const user = window.firebaseAuth.currentUser;
        if (authButtons) authButtons.style.display = 'none';
        if (userProfile) {
            const avatar = userProfile.querySelector('.avatar');
            const userName = userProfile.querySelector('h4');
            if (avatar) avatar.src = user.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.displayName || user.email.split('@')[0])}`;
            if (userName) userName.textContent = user.displayName || user.email.split('@')[0];
            userProfile.style.display = 'flex';
        }
    } else {
        if (authButtons) authButtons.style.display = 'flex';
        if (userProfile) userProfile.style.display = 'none';
    }
}

// Event Listeners
if (loginBtn) loginBtn.addEventListener('click', () => {
    showModal();
    switchTab('login');
});

if (signupBtn) signupBtn.addEventListener('click', () => {
    showModal();
    switchTab('signup');
});

if (closeModal) closeModal.addEventListener('click', hideModal);

window.addEventListener('click', (e) => {
    if (e.target === authModal) {
        hideModal();
    }
});

if (loginTab) loginTab.addEventListener('click', () => switchTab('login'));
if (signupTab) signupTab.addEventListener('click', () => switchTab('signup'));

if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = e.target.email.value;
        const password = e.target.password.value;

        if (!validateEmail(email)) {
            showToast('Please enter a valid email', 'error');
            return;
        }

        if (!login(email, password)) {
            showToast('Invalid email or password', 'error');
            return;
        }
    });
}

if (signupForm) {
    signupForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = e.target.name.value;
        const email = e.target.email.value;
        const password = e.target.password.value;

        if (!validateEmail(email)) {
            showToast('Please enter a valid email', 'error');
            return;
        }

        if (!validatePassword(password)) {
            showToast('Password must be at least 6 characters', 'error');
            return;
        }

        if (!signup(name, email, password)) {
            showToast('Email already exists', 'error');
            return;
        }
    });
}

// Initialize UI based on auth state
document.addEventListener('DOMContentLoaded', () => {
    if (window.firebaseAuth) {
        window.firebaseAuth.onAuthStateChanged(() => {
            updateUIForUser();
        });
    } else {
        updateUIForUser();
    }
});