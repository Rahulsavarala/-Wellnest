// Check if user is logged in using Firebase Auth only
document.addEventListener('DOMContentLoaded', () => {
    if (!window.firebaseAuth) {
        console.error('Firebase Auth not loaded!');
        return;
    }
    window.firebaseAuth.onAuthStateChanged(function(user) {
        if (!user) {
            window.location.href = '../index.html';
        }
    });
});
