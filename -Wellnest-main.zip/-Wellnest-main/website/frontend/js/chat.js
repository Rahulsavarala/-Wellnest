document.addEventListener('DOMContentLoaded', function() {
    const chatMessages = document.getElementById('chatMessages');
    const messageInput = document.getElementById('messageInput');
    const sendButton = document.getElementById('sendMessage');
    const quickResponses = document.querySelectorAll('.quick-response');
    const moodScore = document.getElementById('moodScore');
    
    // Automatically adjust textarea height
    function adjustTextareaHeight() {
        messageInput.style.height = 'auto';
        messageInput.style.height = messageInput.scrollHeight + 'px';
    }

    // Add a message to the chat
    function addMessage(content, isUser = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user-message' : 'ai-message'}`;
        
        const messageContent = document.createElement('div');
        messageContent.className = 'message-content';
        messageContent.textContent = content;
        
        const messageTime = document.createElement('div');
        messageTime.className = 'message-time';
        messageTime.textContent = 'Just now';
        
        messageDiv.appendChild(messageContent);
        messageDiv.appendChild(messageTime);
        
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;

        // If it's a user message, simulate AI response
        if (isUser) {
            setTimeout(() => {
                // Show typing indicator
                const typingDiv = document.createElement('div');
                typingDiv.className = 'message ai-message typing';
                typingDiv.textContent = 'AI is typing...';
                chatMessages.appendChild(typingDiv);
                chatMessages.scrollTop = chatMessages.scrollHeight;

                // Remove typing indicator and show response after delay
                setTimeout(() => {
                    chatMessages.removeChild(typingDiv);
                    addMessage(generateAIResponse(content));
                }, 1500);
            }, 500);
        }
    }

    // Generate AI response based on user input
    function generateAIResponse(userMessage) {
        const lowercaseMessage = userMessage.toLowerCase();
        
        if (lowercaseMessage.includes('feeling good')) {
            return "That's wonderful to hear! What's contributing to your positive mood today? 😊";
        } else if (lowercaseMessage.includes('feeling down')) {
            return "I'm sorry you're feeling down. Would you like to talk about what's troubling you? I'm here to listen. 🤗";
        } else if (lowercaseMessage.includes('stressed')) {
            return "I understand that stress can be overwhelming. Let's try a quick breathing exercise together. Would that help? 🧘‍♂️";
        } else if (lowercaseMessage.includes('advice')) {
            return "I'll do my best to help. Could you tell me more about the situation you'd like advice on? 🤔";
        } else {
            return "Thank you for sharing. How does that make you feel? I'm here to listen and support you. 💭";
        }
    }

    // Event Listeners
    messageInput.addEventListener('input', adjustTextareaHeight);
    
    messageInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            const message = messageInput.value.trim();
            if (message) {
                addMessage(message, true);
                messageInput.value = '';
                adjustTextareaHeight();
            }
        }
    });

    sendButton.addEventListener('click', function() {
        const message = messageInput.value.trim();
        if (message) {
            addMessage(message, true);
            messageInput.value = '';
            adjustTextareaHeight();
        }
    });

    quickResponses.forEach(button => {
        button.addEventListener('click', function() {
            const message = this.textContent;
            addMessage(message, true);
        });
    });

    // Mood tracking
    document.querySelector('.mood-check-btn').addEventListener('click', function() {
        const mood = prompt('On a scale of 1-10, how are you feeling right now?');
        if (mood && !isNaN(mood) && mood >= 1 && mood <= 10) {
            moodScore.textContent = `${mood}/10`;
            addMessage(`I've rated my current mood as ${mood}/10`, true);
        }
    });

    // Crisis resources
    document.querySelector('.resources-btn').addEventListener('click', function() {
        alert('If you need immediate help:\n\n' +
              '• Call 911 for emergencies\n' +
              '• Call 988 for Suicide & Crisis Lifeline\n' +
              '• Text HOME to 741741 for Crisis Text Line');
    });
});