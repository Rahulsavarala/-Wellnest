// DOM Elements
const chatMessages = document.getElementById('chatMessages');
const messageInput = document.getElementById('messageInput');
const sendButton = document.getElementById('sendMessage');
const moodButton = document.getElementById('moodCheck');
const moodIndicator = document.getElementById('moodIndicator');
const quickResponses = document.querySelectorAll('.quick-response');

// State Management
let userMood = 'Not Set';
let isAITyping = false;
let conversationContext = [];

// AI Response Templates with more context-aware responses
const aiResponses = {
    greeting: [
        "Hello! I'm here to support your mental wellness journey. How are you feeling today?",
        "Welcome! This is a safe space to share your thoughts and feelings. How can I help you today?",
        "Hi there! I'm your WeShare companion. Would you like to talk about how you're feeling?"
    ],
    positive: [
        "It's wonderful that you're feeling good! What's contributing to your positive mood?",
        "I'm glad to hear that! Would you like to explore ways to maintain this positive energy?",
        "That's great! Sometimes reflecting on good moments helps us appreciate them more. What's making you happy?"
    ],
    negative: [
        "I hear you, and it's okay to feel this way. Would you like to talk more about what's troubling you?",
        "Thank you for sharing that with me. Sometimes putting feelings into words can help. What's on your mind?",
        "I'm here to listen without judgment. Would you like to explore these feelings together?"
    ],
    stressed: [
        "Let's take a moment together. Would you like to try a quick breathing exercise?",
        "Stress can feel overwhelming. Can you tell me what's causing you to feel stressed?",
        "I understand. Sometimes breaking down our stressors can help. What's the biggest concern right now?"
    ],
    needAdvice: [
        "I'll do my best to help you think things through. What specific area would you like to focus on?",
        "Let's explore this together. Can you tell me more about what's on your mind?",
        "I'm here to help you find clarity. What questions do you have?"
    ],
    breathing: [
        "Let's try a simple breathing exercise. Breathe in for 4 counts, hold for 4, and exhale for 4. Ready?",
        "Would you like to try a calming breath exercise together?",
        "Sometimes taking a few deep breaths can help us reset. Shall we try?"
    ],
    selfCare: [
        "Have you taken any time for self-care today? Even small actions can make a difference.",
        "Remember to be kind to yourself. What's one small thing you could do for your wellbeing right now?",
        "Self-care is important. Would you like some suggestions for simple self-care activities?"
    ]
};

// Enhanced Helper Functions
function getRandomResponse(responses) {
    return responses[Math.floor(Math.random() * responses.length)];
}

function getCurrentTime() {
    return new Date().toLocaleTimeString('en-US', { 
        hour: 'numeric', 
        minute: 'numeric',
        hour12: true 
    });
}

function createMessageElement(content, isAI = false, includeThinkingAnimation = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isAI ? 'ai' : 'user'}`;
    
    const messageContent = document.createElement('div');
    messageContent.className = 'message-content';
    
    if (includeThinkingAnimation) {
        messageContent.innerHTML = `
            <div class="thinking-animation">
                <span>.</span><span>.</span><span>.</span>
            </div>
        `;
    } else {
        messageContent.innerHTML = `<p>${content}</p>`;
    }
    
    const timeSpan = document.createElement('span');
    timeSpan.className = 'message-time';
    timeSpan.textContent = getCurrentTime();
    
    messageDiv.appendChild(messageContent);
    messageDiv.appendChild(timeSpan);
    
    return messageDiv;
}

// Enhanced AI Response Logic
function analyzeMessage(message) {
    message = message.toLowerCase();
    
    if (message.includes('thank')) return 'gratitude';
    if (message.includes('help') || message.includes('advice')) return 'needAdvice';
    if (message.includes('stress') || message.includes('worried')) return 'stressed';
    if (message.includes('happy') || message.includes('good') || message.includes('great')) return 'positive';
    if (message.includes('sad') || message.includes('down') || message.includes('depressed')) return 'negative';
    if (message.includes('breath') || message.includes('calm')) return 'breathing';
    if (message.includes('care') || message.includes('help myself')) return 'selfCare';
    
    return 'general';
}

async function simulateTyping(message) {
    if (isAITyping) return;
    isAITyping = true;
    
    const typingIndicator = createMessageElement('', true, true);
    chatMessages.appendChild(typingIndicator);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    // Simulate AI thinking and typing with variable timing
    const thinkingTime = Math.random() * 1000 + 1000; // 1-2 seconds
    await new Promise(resolve => setTimeout(resolve, thinkingTime));
    
    chatMessages.removeChild(typingIndicator);
    chatMessages.appendChild(createMessageElement(message, true));
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    isAITyping = false;
}

// Enhanced Event Handlers
async function handleSendMessage() {
    const message = messageInput.value.trim();
    if (!message || isAITyping) return;
    
    // Add user message
    chatMessages.appendChild(createMessageElement(message));
    messageInput.value = '';
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    // Analyze message and get appropriate response
    const messageType = analyzeMessage(message);
    let responsePool = aiResponses[messageType] || aiResponses.greeting;
    
    // Add context from mood if set
    if (userMood !== 'Not Set') {
        if (userMood === 'happy' || userMood === 'calm') {
            responsePool = [...responsePool, ...aiResponses.positive];
        } else if (userMood === 'sad' || userMood === 'stressed') {
            responsePool = [...responsePool, ...aiResponses.selfCare];
        }
    }
    
    await simulateTyping(getRandomResponse(responsePool));
}

async function handleMoodCheck() {
    const moods = [
        '😊 Happy',
        '😔 Sad',
        '😫 Stressed',
        '😌 Calm',
        '😐 Neutral',
        '😢 Down',
        '😤 Frustrated',
        '😃 Excited'
    ];
    
    const newMood = moods[Math.floor(Math.random() * moods.length)];
    userMood = newMood.split(' ')[1].toLowerCase();
    
    moodIndicator.innerHTML = `Current Mood: <span class="mood-score">${newMood}</span>`;
    
    // Provide mood-specific response
    let message = "Thank you for sharing your mood. ";
    if (['happy', 'excited', 'calm'].includes(userMood)) {
        message += getRandomResponse(aiResponses.positive);
    } else if (['sad', 'stressed', 'down', 'frustrated'].includes(userMood)) {
        message += getRandomResponse([...aiResponses.negative, ...aiResponses.selfCare]);
    }
    
    await simulateTyping(message);
}

// Quick Response Handlers
async function handleQuickResponse(event) {
    if (isAITyping) return;
    const response = event.target.textContent;
    messageInput.value = response;
    await handleSendMessage();
}

// Event Listeners
messageInput.addEventListener('keypress', async (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        await handleSendMessage();
    }
});

sendButton.addEventListener('click', handleSendMessage);
moodButton.addEventListener('click', handleMoodCheck);

quickResponses.forEach(button => {
    button.addEventListener('click', handleQuickResponse);
});

// Auto-resize textarea
messageInput.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = (this.scrollHeight) + 'px';
});

// Add some CSS for the thinking animation
const style = document.createElement('style');
style.textContent = `
    .thinking-animation {
        display: flex;
        gap: 4px;
        padding: 8px;
    }
    .thinking-animation span {
        animation: thinking 1.4s infinite;
        font-size: 24px;
    }
    .thinking-animation span:nth-child(2) { animation-delay: 0.2s; }
    .thinking-animation span:nth-child(3) { animation-delay: 0.4s; }
    @keyframes thinking {
        0%, 100% { opacity: 0.3; }
        50% { opacity: 1; }
    }
`;
document.head.appendChild(style);

// Initialize
window.addEventListener('load', async () => {
    // Clear any existing messages
    chatMessages.innerHTML = '';
    // Add initial greeting
    await simulateTyping(getRandomResponse(aiResponses.greeting));
});