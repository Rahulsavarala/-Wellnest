// DOM Elements
const chatMessages = document.getElementById('chatMessages');
const messageInput = document.getElementById('messageInput');
const sendButton = document.getElementById('sendMessage');
const moodButton = document.getElementById('moodCheck');
const moodIndicator = document.getElementById('moodIndicator');
const quickResponses = document.querySelectorAll('.quick-response');

// State Management
let userMood = 'Not Set';
let isAITyping = false;

// AI Responses based on mood and context
const aiResponses = {
    greeting: [
        "Hello! How can I support you today?",
        "Welcome back! How are you feeling?",
        "Hi there! I'm here to listen and help."
    ],
    positive: [
        "That's wonderful to hear! What's making you feel good today?",
        "I'm glad you're feeling positive! Would you like to share more?",
        "It's great that you're in a good mood! How can we maintain this energy?"
    ],
    negative: [
        "I'm here to listen. Would you like to talk about what's bothering you?",
        "I'm sorry you're feeling down. Remember, it's okay to not be okay. What's on your mind?",
        "Thank you for sharing. Would you like to explore some coping strategies together?"
    ],
    stressed: [
        "Let's take a deep breath together. What's causing your stress?",
        "Stress can be overwhelming. Would you like to try a quick relaxation exercise?",
        "I'm here to help you manage your stress. What would be most helpful right now?"
    ],
    needAdvice: [
        "I'm here to help. What specific area would you like advice on?",
        "Sometimes talking things through can help. What's on your mind?",
        "I'll do my best to help you find clarity. What are you thinking about?"
    ]
};

// Helper Functions
function getRandomResponse(responses) {
    return responses[Math.floor(Math.random() * responses.length)];
}

function getCurrentTime() {
    return new Date().toLocaleTimeString('en-US', { 
        hour: 'numeric', 
        minute: 'numeric',
        hour12: true 
    });
}

function createMessageElement(content, isAI = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isAI ? 'ai' : 'user'}`;
    
    const messageContent = document.createElement('div');
    messageContent.className = 'message-content';
    messageContent.innerHTML = `<p>${content}</p>`;
    
    const timeSpan = document.createElement('span');
    timeSpan.className = 'message-time';
    timeSpan.textContent = getCurrentTime();
    
    messageDiv.appendChild(messageContent);
    messageDiv.appendChild(timeSpan);
    
    return messageDiv;
}

async function simulateTyping(message) {
    if (isAITyping) return;
    isAITyping = true;
    
    const typingIndicator = createMessageElement('Typing...', true);
    chatMessages.appendChild(typingIndicator);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    // Simulate AI thinking and typing
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    chatMessages.removeChild(typingIndicator);
    chatMessages.appendChild(createMessageElement(message, true));
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    isAITyping = false;
}

// Event Handlers
function handleSendMessage() {
    const message = messageInput.value.trim();
    if (!message || isAITyping) return;
    
    // Add user message
    chatMessages.appendChild(createMessageElement(message));
    messageInput.value = '';
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    // Generate AI response based on context and mood
    let responsePool = aiResponses.greeting;
    if (message.toLowerCase().includes('stress') || userMood === 'stressed') {
        responsePool = aiResponses.stressed;
    } else if (message.toLowerCase().includes('advice') || message.toLowerCase().includes('help')) {
        responsePool = aiResponses.needAdvice;
    } else if (userMood === 'positive') {
        responsePool = aiResponses.positive;
    } else if (userMood === 'negative') {
        responsePool = aiResponses.negative;
    }
    
    simulateTyping(getRandomResponse(responsePool));
}

function handleMoodCheck() {
    const moods = ['😊 Happy', '😔 Sad', '😫 Stressed', '😌 Calm', '😐 Neutral'];
    const newMood = moods[Math.floor(Math.random() * moods.length)];
    userMood = newMood.split(' ')[1].toLowerCase();
    
    moodIndicator.innerHTML = `Current Mood: <span class="mood-score">${newMood}</span>`;
    
    // Provide feedback based on mood
    let message = "Thank you for sharing your mood. ";
    if (userMood === 'happy' || userMood === 'calm') {
        message += getRandomResponse(aiResponses.positive);
    } else if (userMood === 'sad' || userMood === 'stressed') {
        message += getRandomResponse(aiResponses.negative);
    }
    
    simulateTyping(message);
}

// Quick Response Handlers
function handleQuickResponse(event) {
    const response = event.target.textContent;
    messageInput.value = response;
    handleSendMessage();
}

// Event Listeners
messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSendMessage();
    }
});

sendButton.addEventListener('click', handleSendMessage);
moodButton.addEventListener('click', handleMoodCheck);
quickResponses.forEach(button => {
    button.addEventListener('click', handleQuickResponse);
});

// Auto-resize textarea
messageInput.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = (this.scrollHeight) + 'px';
});

// Initial greeting
window.addEventListener('load', () => {
    setTimeout(() => {
        simulateTyping(getRandomResponse(aiResponses.greeting));
    }, 500);
});