// Data management
let currentUser = null;
let posts = [];
let connections = [];
let stories = [];
let moodHistory = [];

const API_BASE = 'http://localhost:5000';
const DEV_MODE = localStorage.getItem('devMode') === 'true';

document.addEventListener('DOMContentLoaded', function() {
    // DEMO DATA: Add sample posts and stories if not present
    if (!localStorage.getItem('posts')) {
        localStorage.setItem('posts', JSON.stringify([
            {
                id: 'demo1',
                userId: 'demo@user.com',
                userName: 'Demo User',
                userAvatar: 'https://ui-avatars.com/api/?name=Demo+User',
                content: 'This is a demo post to show the layout and style of the feed. Welcome to WeShare! 💙',
                moodScore: 8,
                timestamp: Date.now() - 1000 * 60 * 60,
                likes: [],
                comments: [],
                mediaUrl: null,
                mediaType: null
            }
        ]));
    }
    if (!localStorage.getItem('stories')) {
        localStorage.setItem('stories', JSON.stringify([
            {
                id: 'story1',
                userId: 'demo@user.com',
                userName: 'Demo User',
                userAvatar: 'https://ui-avatars.com/api/?name=Demo+User',
                content: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=facearea&w=256&h=256',
                timestamp: Date.now() - 1000 * 60 * 30
            }
        ]));
    }
    initializeDashboard();
});

function initializeDashboard() {
    // Use Firebase Auth for authentication check
    firebase.auth().onAuthStateChanged(function(user) {
        if (!user) {
            window.location.href = '../index.html';
            return;
        }
        // Always build currentUser from Firebase user only
        currentUser = {
            name: user.displayName || user.email.split('@')[0],
            email: user.email,
            avatar: user.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.displayName || user.email.split('@')[0])}`
        };
        // Optionally load other non-auth data from localStorage
        connections = [];
        moodHistory = [];

        // Initialize all dashboard components
        updateUserProfile();
        setupNavigation();
        initializeFeed();
        updateSuggestions();
        initializeStories();
        // Removed mood prompt from dashboard
    });
}

function updateUserProfile() {
    // Update sidebar avatar and name
    const sidebarAvatar = document.getElementById('sidebarAvatar');
    const sidebarName = document.getElementById('sidebarName');
    if (sidebarAvatar) sidebarAvatar.src = currentUser.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser.name)}`;
    if (sidebarName) sidebarName.textContent = currentUser.name;

    // Update post input avatar
    const postAvatar = document.getElementById('currentUserAvatar');
    if (postAvatar) postAvatar.src = currentUser.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser.name)}`;

    // Update any other user profile section (legacy)
    const userProfile = document.querySelector('.user-profile');
    if (userProfile) {
        const avatar = userProfile.querySelector('.avatar');
        const userName = userProfile.querySelector('h4');
        if (avatar) avatar.src = currentUser.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser.name)}`;
        if (userName) userName.textContent = currentUser.name;
    }
}

function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            // Let anchors navigate by default; only handle items without href
            const link = e.currentTarget.getAttribute('href');
            if (link && link.trim() !== '#') {
                return; // allow native navigation
            }
            // Fallback: derive from text if no href present
            const page = e.currentTarget.textContent.trim().toLowerCase();
            switch(page) {
                case 'chat':
                    window.location.href = 'chat.html';
                    break;
                case 'progress':
                    window.location.href = 'progress.html';
                    break;
                case 'goals':
                    window.location.href = 'goals.html';
                    break;
                case 'resources':
                    window.location.href = 'resources.html';
                    break;
                default:
                    // do nothing; allow default behavior
            }
        });
    });
}

function initializeFeed() {
    const feed = document.querySelector('.feed');
    if (!feed) return;

    // Clear existing posts
    feed.innerHTML = '';

    // Create post input area
    const postInput = document.createElement('div');
    postInput.className = 'post create-post';
    postInput.innerHTML = `
        <div class="post-header">
            <img src="${currentUser.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser.name)}`}" alt="Your avatar" class="avatar">
            <div class="post-input">
                <textarea placeholder="Share your thoughts or feelings..."></textarea>
                <div class="post-actions">
                    <div class="mood-selector">
                        <label>Mood:</label>
                        <select>
                            ${Array.from({length: 10}, (_, i) => `<option value="${i+1}">${i+1}/10</option>`).join('')}
                        </select>
                    </div>
                    <input type="file" class="media-input" accept="image/*,video/*">
                    <button class="btn btn-primary">Share</button>
                </div>
            </div>
        </div>
    `;

    // Add post creation handler
    const shareButton = postInput.querySelector('button');
    shareButton.addEventListener('click', createNewPost);

    feed.appendChild(postInput);

    // Load posts from backend
    fetch(`${API_BASE}/api/posts`)
        .then(res => res.json())
        .then(apiPosts => {
            posts = apiPosts.map(p => ({
                id: p.id,
                userId: p.user,
                userName: p.user,
                userAvatar: p.avatar,
                content: p.text,
                moodScore: p.mood,
                timestamp: new Date(p.time).getTime(),
                likes: [],
                comments: [],
                mediaUrl: p.media || null,
                mediaType: p.mediaType || null
            }));
            posts.sort((a, b) => b.timestamp - a.timestamp)
                .forEach(post => renderPost(post));
        })
        .catch(() => {
            // Fallback to localStorage if API fails
            posts = JSON.parse(localStorage.getItem('posts') || '[]');
            posts.sort((a, b) => b.timestamp - a.timestamp)
                .forEach(post => renderPost(post));
        });
}

function createNewPost() {
    const content = document.querySelector('.create-post textarea').value.trim();
    const moodScore = document.querySelector('.create-post select').value;
    const mediaInput = document.querySelector('.create-post .media-input');

    // Require either text or a media file
    if (!content && !(mediaInput && mediaInput.files && mediaInput.files[0])) {
        showToast('Please add text or attach an image/video.', 'error');
        return;
    }

    const avatarUrl = currentUser.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser.name)}`;

    const sendPost = (mediaBase64 = null, mime = null) => {
        const body = {
            user: currentUser.name,
            avatar: avatarUrl,
            text: content,
            mood: Number(moodScore),
            media: mediaBase64,
            mediaType: mime
        };

        fetch(`${API_BASE}/api/posts`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        }).then(res => res.json())
            .then(data => {
                const newPost = {
                    id: data.postId || Date.now().toString(),
                    userId: currentUser.email,
                    userName: currentUser.name,
                    userAvatar: avatarUrl,
                    content: content,
                    moodScore: Number(moodScore),
                    timestamp: Date.now(),
                    likes: [],
                    comments: [],
                    mediaUrl: data.media || null,
                    mediaType: data.mediaType || null
                };
                posts.unshift(newPost);
                renderPost(newPost, true);
                document.querySelector('.create-post textarea').value = '';
                if (mediaInput) mediaInput.value = '';
                showToast('Post shared successfully!', 'success');
            })
            .catch(() => {
                showToast('Failed to share post. Please try again.', 'error');
            });
    };

    // If a file is selected, convert to base64 first
    const file = mediaInput && mediaInput.files && mediaInput.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = () => sendPost(reader.result, file.type);
        reader.onerror = () => showToast('Failed to read media file.', 'error');
        reader.readAsDataURL(file);
    } else {
        sendPost();
    }
}

function renderPost(post, prepend = false) {
    const feed = document.querySelector('.feed');
    const postElement = document.createElement('article');
    postElement.className = 'post';
    postElement.dataset.postId = post.id;

    postElement.innerHTML = `
        <div class="post-header">
            <img src="${post.userAvatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(post.userName)}`}" alt="${post.userName}" class="avatar">
            <div class="post-info">
                <h4>${post.userName}</h4>
                <p>${getTimeAgo(post.timestamp)}</p>
            </div>
            <div class="mood-score">Mood: ${post.moodScore}/10</div>
        </div>
        <div class="post-content">
            <p>${post.content}</p>
            ${post.mediaUrl ? (post.mediaType && post.mediaType.startsWith('video/')
                ? `<video controls src="${post.mediaUrl}" style="max-width:100%; border-radius:8px; margin-top:8px;"></video>`
                : `<img src="${post.mediaUrl}" alt="media" style="max-width:100%; border-radius:8px; margin-top:8px;"/>`) : ''}
        </div>
        <div class="post-actions">
            <button class="like-btn ${post.likes.includes(currentUser.email) ? 'active' : ''}">
                ❤️ ${post.likes.length} Like${post.likes.length !== 1 ? 's' : ''}
            </button>
            <button class="comment-btn">
                💭 ${post.comments.length} Comment${post.comments.length !== 1 ? 's' : ''}
            </button>
            <button class="share-btn">⤴️ Share</button>
        </div>
        <div class="comments-section" style="display: none;">
            <div class="comments-list">
                ${post.comments.map(comment => `
                    <div class="comment">
                        <img src="${comment.userAvatar}" alt="${comment.userName}" class="avatar">
                        <div class="comment-content">
                            <h5>${comment.userName}</h5>
                            <p>${comment.content}</p>
                        </div>
                    </div>
                `).join('')}
            </div>
            <div class="comment-input">
                <textarea placeholder="Write a comment..."></textarea>
                <button class="btn btn-primary">Send</button>
            </div>
        </div>
    `;

    // Add event listeners
    const likeBtn = postElement.querySelector('.like-btn');
    const commentBtn = postElement.querySelector('.comment-btn');
    const shareBtn = postElement.querySelector('.share-btn');
    const commentInput = postElement.querySelector('.comment-input textarea');
    const sendCommentBtn = postElement.querySelector('.comment-input button');

    likeBtn.addEventListener('click', () => toggleLike(post.id));
    commentBtn.addEventListener('click', () => toggleComments(post.id));
    shareBtn.addEventListener('click', () => sharePost(post));
    sendCommentBtn.addEventListener('click', () => addComment(post.id, commentInput.value));

    const feedFirstChild = feed.firstChild;
    if (prepend && feedFirstChild) {
        feed.insertBefore(postElement, feedFirstChild.nextSibling);
    } else {
        feed.appendChild(postElement);
    }
}

function toggleLike(postId) {
    const postIndex = posts.findIndex(p => p.id === postId);
    if (postIndex === -1) return;

    const likeIndex = posts[postIndex].likes.indexOf(currentUser.email);
    if (likeIndex === -1) {
        posts[postIndex].likes.push(currentUser.email);
    } else {
        posts[postIndex].likes.splice(likeIndex, 1);
    }

    updatePostElement(posts[postIndex]);
}

function toggleComments(postId) {
    const post = document.querySelector(`[data-post-id="${postId}"]`);
    const commentsSection = post.querySelector('.comments-section');
    commentsSection.style.display = commentsSection.style.display === 'none' ? 'block' : 'none';
}

function addComment(postId, content) {
    if (!content.trim()) return;

    const postIndex = posts.findIndex(p => p.id === postId);
    if (postIndex === -1) return;

    const comment = {
        id: Date.now().toString(),
        userId: currentUser.email,
        userName: currentUser.name,
        userAvatar: currentUser.avatar,
        content: content.trim(),
        timestamp: Date.now()
    };

    posts[postIndex].comments.push(comment);
    updatePostElement(posts[postIndex]);
}

function updatePostElement(post) {
    const postElement = document.querySelector(`[data-post-id="${post.id}"]`);
    if (!postElement) return;

    // Update like button
    const likeBtn = postElement.querySelector('.like-btn');
    likeBtn.className = `like-btn ${post.likes.includes(currentUser.email) ? 'active' : ''}`;
    likeBtn.innerHTML = `❤️ ${post.likes.length} Like${post.likes.length !== 1 ? 's' : ''}`;

    // Update comment button and section
    const commentBtn = postElement.querySelector('.comment-btn');
    commentBtn.innerHTML = `💭 ${post.comments.length} Comment${post.comments.length !== 1 ? 's' : ''}`;

    const commentsList = postElement.querySelector('.comments-list');
    commentsList.innerHTML = post.comments.map(comment => `
        <div class="comment">
            <img src="${comment.userAvatar}" alt="${comment.userName}" class="avatar">
            <div class="comment-content">
                <h5>${comment.userName}</h5>
                <p>${comment.content}</p>
            </div>
        </div>
    `).join('');

    // Clear comment input
    const commentInput = postElement.querySelector('.comment-input textarea');
    if (commentInput) commentInput.value = '';
}

function sharePost(post) {
    if (navigator.share) {
        navigator.share({
            title: 'WeShare Post',
            text: `${post.userName} shared: ${post.content}`,
            url: window.location.href
        }).catch(() => {
            showToast('Sharing failed. Please try again.', 'error');
        });
    } else {
        showToast('Sharing is not supported on this device.', 'error');
    }
}

function updateSuggestions() {
    // Get all users except current user and connections
    const users = JSON.parse(localStorage.getItem('users') || '[]')
        .filter(user => user.email !== currentUser.email && 
                      !connections.some(conn => conn.email === user.email))
        .slice(0, 3);  // Show only 3 suggestions

    const suggestionList = document.querySelector('.suggestion-list');
    if (!suggestionList) return;

    suggestionList.innerHTML = users.map(user => `
        <div class="suggestion-card">
            <img src="${user.avatar}" alt="${user.name}" class="avatar">
            <div class="suggestion-info">
                <h4>${user.name}</h4>
                <p>${user.role || 'Community Member'}</p>
            </div>
            <button class="connect-btn" data-email="${user.email}">Connect</button>
        </div>
    `).join('');

    // Add connect button handlers
    const connectButtons = document.querySelectorAll('.connect-btn');
    connectButtons.forEach(button => {
        button.addEventListener('click', () => {
            const userEmail = button.dataset.email;
            const user = users.find(u => u.email === userEmail);
            if (user) {
                connections.push(user);
                localStorage.setItem('connections', JSON.stringify(connections));
                button.textContent = 'Connected';
                button.disabled = true;
                showToast(`Connected with ${user.name}!`, 'success');
            }
        });
    });
}

function getTimeAgo(timestamp) {
    const seconds = Math.floor((Date.now() - timestamp) / 1000);
    if (seconds < 60) return `${seconds}s ago`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
}

function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// Story Management
function initializeStories() {
    const storiesSection = document.querySelector('.stories-section');
    if (!storiesSection) return;

    // Clear existing stories
    storiesSection.innerHTML = '';

    // Add story creation button
    const addStoryBtn = document.createElement('div');
    addStoryBtn.className = 'story-card add-story';
    addStoryBtn.innerHTML = `
        <div class="add-story-icon">+</div>
        <p>Add Story</p>
    `;
    addStoryBtn.addEventListener('click', createStory);
    storiesSection.appendChild(addStoryBtn);

    // Load stories
    const loadFromLocal = () => {
        stories = JSON.parse(localStorage.getItem('stories') || '[]');
        const activeStories = stories.filter(story => 
            story.timestamp > Date.now() - 24 * 60 * 60 * 1000
        );
        const myStory = activeStories.find(s => s.userId === currentUser?.email || s.userName === currentUser?.name);
        if (myStory) updateAddStoryCard(myStory);
        activeStories
            .filter(s => !(myStory && s.id === myStory.id))
            .forEach(story => {
                const storyCard = createStoryCard(story);
                storiesSection.appendChild(storyCard);
            });
    };

    if (DEV_MODE) {
        loadFromLocal();
    } else {
        // Load from backend (last 24h filtering client-side)
        fetch(`${API_BASE}/api/stories`)
            .then(res => res.json())
            .then(apiStories => {
                stories = apiStories.map(s => ({
                    id: s.id,
                    userId: s.user,
                    userName: s.user,
                    userAvatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(s.user)}`,
                    content: s.url,
                    timestamp: new Date(s.time).getTime()
                }));
                const activeStories = stories.filter(story => 
                    story.timestamp > Date.now() - 24 * 60 * 60 * 1000
                );
                const myStory = activeStories.find(s => s.userId === currentUser?.email || s.userName === currentUser?.name);
                if (myStory) updateAddStoryCard(myStory);
                activeStories
                    .filter(s => !(myStory && s.id === myStory.id))
                    .forEach(story => {
                        const storyCard = createStoryCard(story);
                        storiesSection.appendChild(storyCard);
                    });
            })
            .catch(() => {
                loadFromLocal();
            });
    }
}

function createStory() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    
    input.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        try {
            const base64 = await fileToBase64(file);

            // Prefer backend even in dev mode so Firebase is used

            // Save to backend
            const res = await fetch(`${API_BASE}/api/stories`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ user: currentUser.name, url: base64, type: 'image' })
            });
            const data = await res.json();

            const story = {
                id: data.storyId || Date.now().toString(),
                userId: currentUser.email,
                userName: currentUser.name,
                userAvatar: currentUser.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser.name)}`,
                content: data.url || base64,
                timestamp: Date.now()
            };

            stories.unshift(story);
            // Render my story inside the + card instead of adding a separate card
            updateAddStoryCard(story);
            // Immediately show the story in a popup so it isn't scrolled to view
            viewStory(story);
            showToast('Story created successfully!', 'success');
        } catch (error) {
            showToast('Failed to create story. Please try again.', 'error');
        }
    };

    input.click();
}

function createStoryCard(story) {
    const div = document.createElement('div');
    div.className = 'story-card';
    div.dataset.storyId = story.id;
    div.innerHTML = `
        <img src="${story.userAvatar}" alt="${story.userName}" class="story-avatar">
        <p>${story.userName}</p>
        <div class="story-border"></div>
    `;

    div.addEventListener('click', () => viewStory(story));
    return div;
}

function updateAddStoryCard(story) {
    const addCard = document.querySelector('.stories-section .add-story');
    if (!addCard) return;
    const icon = addCard.querySelector('.add-story-icon');
    const label = addCard.querySelector('p');
    if (icon) icon.replaceWith(Object.assign(document.createElement('img'), { src: story.userAvatar, className: 'story-avatar' }));
    if (label) label.textContent = 'Your Story';
    addCard.onclick = () => viewStory(story);
}

function viewStory(story) {
    const isOwner = story.userName === currentUser.name || story.userId === currentUser.email;
    const modal = document.createElement('div');
    modal.className = 'story-modal';
    modal.innerHTML = `
        <div class="story-content">
            <div class="story-header">
                <img src="${story.userAvatar}" alt="${story.userName}" class="avatar">
                <span>${story.userName}</span>
                <span class="story-time">${getTimeAgo(story.timestamp)}</span>
                <div class="story-actions">
                    ${isOwner ? '<button class="delete-story-btn">Delete</button>' : ''}
                    <button class="close-btn">×</button>
                </div>
            </div>
            <img src="${story.content}" alt="Story content" class="story-image">
        </div>
    `;

    // Close on backdrop click or close button
    modal.addEventListener('click', (e) => {
        if (e.target === modal || e.target.classList.contains('close-btn')) {
            modal.remove();
        }
    });

    // Delete button handler
    if (isOwner) {
        const deleteBtn = modal.querySelector('.delete-story-btn');
        deleteBtn.addEventListener('click', async () => {
            try {
                const res = await fetch(`${API_BASE}/api/stories/${story.id}`, { method: 'DELETE' });
                if (!res.ok) throw new Error('Delete failed');
                // Remove from local array and UI
                stories = stories.filter(s => s.id !== story.id);
                const card = document.querySelector(`.story-card[data-story-id="${story.id}"]`);
                if (card && card.parentNode) card.parentNode.removeChild(card);
                // Reset the add story card back to + if this was my story
                const addCard = document.querySelector('.stories-section .add-story');
                if (addCard) {
                    addCard.innerHTML = `
                        <div class="add-story-icon">+</div>
                        <p>Add Story</p>
                    `;
                    addCard.onclick = createStory;
                }
                modal.remove();
                showToast('Story deleted', 'success');
            } catch (_) {
                showToast('Failed to delete story', 'error');
            }
        });
    }

    document.body.appendChild(modal);

    // Auto-close after 10 seconds
    setTimeout(() => modal.remove(), 10000);
}

function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}

// Mood Tracking System
function setupMoodTracking() {
    const moodPrompt = document.querySelector('.mood-tracking') || createMoodPrompt();
    updateMoodHistory();
}

function createMoodPrompt() {
    const currentDate = new Date().toDateString();
    const todayMood = moodHistory.find(m => new Date(m.timestamp).toDateString() === currentDate);
    
    if (todayMood) {
        return null; // Don't show prompt if mood already logged today
    }

    const promptDiv = document.createElement('div');
    promptDiv.className = 'mood-tracking';
    promptDiv.innerHTML = `
        <div class="mood-prompt">
            <h3>How are you feeling today?</h3>
            <div class="mood-options">
                <button data-mood="1" class="mood-btn">😞 Very Low</button>
                <button data-mood="3" class="mood-btn">😕 Low</button>
                <button data-mood="5" class="mood-btn">😐 Neutral</button>
                <button data-mood="7" class="mood-btn">🙂 Good</button>
                <button data-mood="10" class="mood-btn">😊 Great</button>
            </div>
        </div>
    `;

    promptDiv.querySelectorAll('.mood-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const mood = {
                score: parseInt(btn.dataset.mood),
                timestamp: Date.now()
            };

            moodHistory.push(mood);
            localStorage.setItem('moodHistory', JSON.stringify(moodHistory));
            
            // Update UI
            promptDiv.innerHTML = `
                <div class="mood-logged">
                    <h3>Today's Mood: ${btn.textContent}</h3>
                    <p>Keep tracking your mood daily to see patterns over time!</p>
                </div>
            `;

            showToast('Mood logged successfully!', 'success');
            updateMoodHistory();
        });
    });

    // Insert after the stories section
    const storiesSection = document.querySelector('.stories-section');
    if (storiesSection) {
        storiesSection.parentNode.insertBefore(promptDiv, storiesSection.nextSibling);
    }

    return promptDiv;
}

function updateMoodHistory() {
    // Create mood chart if it doesn't exist
    let moodChart = document.querySelector('.mood-chart');
    if (!moodChart) {
        moodChart = document.createElement('div');
        moodChart.className = 'mood-chart';
        document.querySelector('.main-content').appendChild(moodChart);
    }

    // Process last 7 days of mood data
    const lastWeek = moodHistory
        .filter(m => m.timestamp > Date.now() - 7 * 24 * 60 * 60 * 1000)
        .sort((a, b) => a.timestamp - b.timestamp);

    // Create chart visualization
    const chartData = lastWeek.map(m => {
        const date = new Date(m.timestamp);
        return `
            <div class="chart-bar" style="height: ${m.score * 10}%">
                <div class="bar-label">${m.score}/10</div>
                <div class="bar-date">${date.toLocaleDateString('en-US', { weekday: 'short' })}</div>
            </div>
        `;
    }).join('');

    moodChart.innerHTML = `
        <h3>Your Mood History</h3>
        <div class="chart-container">
            ${chartData}
        </div>
    `;
}
