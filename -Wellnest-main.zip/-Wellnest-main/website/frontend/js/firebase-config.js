// Firebase configuration (MATCH index.html)
const firebaseConfig = {
  apiKey: "AIzaSyBEJPC2HW01ZeVkbS4W98FzkOG6vjK3c1M",
  authDomain: "weshare-7fb42.firebaseapp.com",
  projectId: "weshare-7fb42",
  storageBucket: "weshare-7fb42.firebasestorage.app",
  messagingSenderId: "119122353433",
  appId: "1:119122353433:web:6b55bc9490fdaf8d7bf988",
  measurementId: "G-TP18753B52"
};

// Initialize Firebase
try {
    firebase.initializeApp(firebaseConfig);
    const auth = firebase.auth();
    
    // Export for use in other files
    window.firebaseAuth = auth;
    
    console.log('Firebase initialized successfully');
} catch (error) {
    console.error('Firebase initialization error:', error);
    alert('Firebase configuration error. Please check the setup guide.');
}
