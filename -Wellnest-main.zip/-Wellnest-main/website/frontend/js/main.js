
document.addEventListener('DOMContentLoaded', function() {
    // Modal Elements
    const modal = document.getElementById('authModal');
    const getStartedBtn = document.getElementById('getStarted');
    const modalClose = document.getElementById('modalClose');
    const modalTabs = document.querySelectorAll('.modal-tab');
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    
    // Show/Hide Modal
    function showModal() {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function hideModal() {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }

    // Modal Event Listeners
    getStartedBtn.addEventListener('click', function(e) {
        e.preventDefault();
        showModal();
    });

    modalClose.addEventListener('click', hideModal);

    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            hideModal();
        }
    });

    // Tab Switching
    modalTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Update active tab
            modalTabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');

            // Show/hide appropriate form
            const isLogin = this.dataset.tab === 'login';
            loginForm.style.display = isLogin ? 'block' : 'none';
            signupForm.style.display = isLogin ? 'none' : 'block';
        });
    });

    // ✅ UPDATED: Real Firebase Authentication (NO localStorage)
    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const email = this.querySelector('input[type="email"]').value;
        const password = this.querySelector('input[type="password"]').value;
        console.log('Login attempt:', { email });
        try {
            // Use Firebase Auth
            const userCredential = await window.firebaseAuth.signInWithEmailAndPassword(email, password);
            // Redirect to dashboard
            window.location.href = 'html/dashboard.html';
        } catch (error) {
            console.error('Login error:', error);
            alert('Login failed: ' + error.message);
        }
    });

    signupForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const name = this.querySelector('input[type="text"]').value;
        const email = this.querySelector('input[type="email"]').value;
        const password = this.querySelector('input[type="password"]').value;
        console.log('Signup attempt:', { name, email });
        try {
            // Create user with Firebase Auth
            const userCredential = await window.firebaseAuth.createUserWithEmailAndPassword(email, password);
            const user = userCredential.user;
            // Update profile with name
            await user.updateProfile({ displayName: name });
            // Redirect to dashboard
            window.location.href = 'html/dashboard.html';
        } catch (error) {
            console.error('Signup error:', error);
            alert('Signup failed: ' + error.message);
        }
    });

    // Feature Cards Animation (unchanged)
    const cards = document.querySelectorAll('.feature-card');
    
    function checkScroll() {
        cards.forEach(card => {
            const cardTop = card.getBoundingClientRect().top;
            if (cardTop < window.innerHeight - 100) {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }
        });
    }

    // Initial style for cards
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.5s ease-out';
    });

    // Check card positions on scroll
    window.addEventListener('scroll', checkScroll);
    checkScroll(); // Initial check
});
