// Story Management
class StoryManager {
    constructor() {
        this.stories = JSON.parse(localStorage.getItem('stories') || '[]');
        this.initializeStories();
    }

    initializeStories() {
        const storiesSection = document.querySelector('.stories-section');
        this.renderStories();
        this.setupStoryCreation();
    }

    renderStories() {
        const storiesSection = document.querySelector('.stories-section');
        const addStoryCard = storiesSection.querySelector('.add-story');
        
        // Clear existing stories except the add story card
        while (storiesSection.lastChild && !storiesSection.lastChild.classList.contains('add-story')) {
            storiesSection.removeChild(storiesSection.lastChild);
        }

        // Get current user's viewed stories
        // Use Firebase Auth for user state
        const user = window.firebaseAuth && window.firebaseAuth.currentUser;
        if (!user) return;
        const currentUser = {
            name: user.displayName || user.email.split('@')[0],
            email: user.email,
            avatar: user.photoURL || ''
        };
        const viewedStories = new Set(JSON.parse(localStorage.getItem(`viewedStories_${currentUser.email}`) || '[]'));

        // Render stories
        this.stories
            .filter(story => story.timestamp > Date.now() - 24 * 60 * 60 * 1000) // Show stories from last 24 hours
            .forEach(story => {
                const storyCard = document.createElement('div');
                storyCard.className = 'story-card';
                storyCard.innerHTML = `
                    <div class="story-avatar ${viewedStories.has(story.id) ? 'viewed' : ''}" 
                         style="background-image: url(${story.userAvatar})">
                    </div>
                    <p>${story.userName}</p>
                `;

                storyCard.addEventListener('click', () => this.viewStory(story));
                storiesSection.appendChild(storyCard);
            });
    }

    setupStoryCreation() {
        const addStoryBtn = document.querySelector('.add-story');
        if (addStoryBtn) {
            addStoryBtn.addEventListener('click', () => this.createStory());
        }
    }

    async createStory() {
        // Use Firebase Auth for user state
        const user = window.firebaseAuth && window.firebaseAuth.currentUser;
        if (!user) return;
        const currentUser = {
            name: user.displayName || user.email.split('@')[0],
            email: user.email,
            avatar: user.photoURL || ''
        };
        if (!currentUser) return;

        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';

        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (file) {
                try {
                    // Convert image to base64
                    const base64 = await this.getBase64(file);
                    
                    const story = {
                        id: Date.now().toString(),
                        userId: currentUser.email,
                        userName: currentUser.name,
                        userAvatar: currentUser.avatar,
                        content: base64,
                        timestamp: Date.now()
                    };

                    this.stories.unshift(story);
                    localStorage.setItem('stories', JSON.stringify(this.stories));
                    this.renderStories();
                    
                    showToast('Story created successfully!', 'success');
                } catch (error) {
                    showToast('Failed to create story. Please try again.', 'error');
                }
            }
        };

        input.click();
    }

    getBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = error => reject(error);
        });
    }

    viewStory(story) {
        const modal = document.createElement('div');
        modal.className = 'story-modal';
        modal.innerHTML = `
            <div class="story-modal-content">
                <div class="story-header">
                    <img src="${story.userAvatar}" alt="${story.userName}" class="avatar">
                    <span>${story.userName}</span>
                    <span class="story-time">${this.getTimeAgo(story.timestamp)}</span>
                </div>
                <img src="${story.content}" alt="Story content" class="story-image">
            </div>
        `;

        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });

        // Mark story as viewed
        // Use Firebase Auth for user state
        const user = window.firebaseAuth && window.firebaseAuth.currentUser;
        if (!user) return;
        const currentUser = {
            name: user.displayName || user.email.split('@')[0],
            email: user.email,
            avatar: user.photoURL || ''
        };
        const viewedStories = new Set(JSON.parse(localStorage.getItem(`viewedStories_${currentUser.email}`) || '[]'));
        viewedStories.add(story.id);
        localStorage.setItem(`viewedStories_${currentUser.email}`, JSON.stringify([...viewedStories]));

        // Remove story after 5 seconds
        setTimeout(() => {
            modal.remove();
            this.renderStories();
        }, 5000);

        document.body.appendChild(modal);
    }

    getTimeAgo(timestamp) {
        const seconds = Math.floor((Date.now() - timestamp) / 1000);
        if (seconds < 60) return `${seconds}s ago`;
        const minutes = Math.floor(seconds / 60);
        if (minutes < 60) return `${minutes}m ago`;
        const hours = Math.floor(minutes / 60);
        if (hours < 24) return `${hours}h ago`;
        return `${Math.floor(hours / 24)}d ago`;
    }
}

// Initialize Story Manager when document is ready
document.addEventListener('DOMContentLoaded', () => {
    new StoryManager();
});