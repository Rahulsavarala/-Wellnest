// Theme management
function initTheme() {
    // Check for saved theme preference, default to light
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeToggle(savedTheme);
}

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    // Update theme
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    updateThemeToggle(newTheme);
}

function updateThemeToggle(theme) {
    const toggle = document.getElementById('themeToggle');
    if (toggle) {
        toggle.querySelector('.theme-toggle-light').style.display = theme === 'dark' ? 'block' : 'none';
        toggle.querySelector('.theme-toggle-dark').style.display = theme === 'light' ? 'block' : 'none';
    }
}

// Initialize theme
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    
    // Add theme toggle listener
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }
});